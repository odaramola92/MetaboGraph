"""Tab implementations for GUI"""
